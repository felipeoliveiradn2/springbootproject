package com.projectspringboot.projectspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectspringApplication.class, args);
	}

}
